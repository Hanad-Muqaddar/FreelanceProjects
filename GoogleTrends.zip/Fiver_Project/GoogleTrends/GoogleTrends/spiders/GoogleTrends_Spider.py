import scrapy
import json
from pytrends.request import TrendReq
from pymongo import MongoClient
from GoogleTrends import settings
import datetime

class GoogletrendsSpiderSpider(scrapy.Spider):
    name = 'GoogleTrends_Spider'
    
    def start_requests(self):
        client = MongoClient('mongodb://localhost/')
        filter={}
        db_name = settings.Readind_Database
        collection_name = settings.Collection_For_Reading_Records
        result = client[db_name][collection_name].find(filter=filter)
        for i in result:
            prod_obj = {}
            prod_obj['URL'] = i['Product']['URL']
            prod_obj['Model'] = i['Product']['Model']
            prod_obj['Version'] = i['Product']['Version']
            d = {}
            d['Prod_Data'] = prod_obj
            d['Searching_Keyword'] = i['Product']['Model']
            try:
                if d['Searching_Keyword'].strip() == "":
                    continue
            except:
                continue
            yield scrapy.Request(url=prod_obj['URL'], callback=self.parse, meta=d)
    
    def parse(self, response):
        item = {}
        try:
            item['Product'] = response.meta.get('Prod_Data')
        except:
            item['Product'] = {}
        try:
            item['Searching_Keyword'] = response.meta.get('Searching_Keyword')
        except:
            item['Searching_Keyword'] = ""
        item['Time_Period'] = "Past 30 days"
        item['Country_Name'] = "WorldWide"
        item['Category'] = "All Categories"
        item['Search'] = "Web Search"

        pytrends = TrendReq(hl='en-US', tz=360, timeout=(10,25), proxies=[f'http://scraperapi:{settings.API_KEY}@proxy-server.scraperapi.com:8001',], retries=3, backoff_factor=0.1, requests_args={'verify':False})
        kw_list = [item['Searching_Keyword']]
        
        pytrends.build_payload(kw_list, cat=0, timeframe='today 1-m', geo="", gprop='')
        
        interest_over_time_df = pytrends.interest_over_time()
        interest_over_time_df_tail = interest_over_time_df.tail(1)
        interest_over_time_df_tail = interest_over_time_df_tail.reset_index()
        interest_over_time_data = {str(row['date']).replace(" 00:00:00","") :row[item['Searching_Keyword']] for index, row in interest_over_time_df_tail.iterrows()}
        item['Interest_Over_Time'] = interest_over_time_data

        interest_By_Region = pytrends.interest_by_region(resolution='COUNTRY', inc_low_vol=True, inc_geo_code=False)
        interest_By_Region_df = interest_By_Region.reset_index()
        interest_By_Region_df_sort = interest_By_Region_df.sort_values(by=item['Searching_Keyword'], ascending=False)
        interest_over_time_data = {str(row['geoName']):row[item['Searching_Keyword']] for index, row in interest_By_Region_df_sort.iterrows()}
        item['Interest_Over_Region'] = interest_over_time_data
        item['Last_Updated'] = datetime.datetime.now()
        yield item
